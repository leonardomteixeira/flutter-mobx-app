import 'package:flutter/material.dart';
import 'package:mobx_flutter_app/app/app_module.dart';

void main() => runApp(AppModule());
