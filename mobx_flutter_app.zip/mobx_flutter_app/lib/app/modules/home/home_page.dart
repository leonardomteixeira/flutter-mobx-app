import 'package:flutter/material.dart';
import 'package:mobx_flutter_app/app/modules/home/components/item/item_widget.dart';
import 'package:mobx_flutter_app/app/modules/home/home_module.dart';
import 'package:mobx_flutter_app/app/shared/models/todo_models.dart';

import 'home_controller.dart';

class HomePage extends StatefulWidget {
  final String title;
  const HomePage({Key key, this.title = "To do List"}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    final controller = HomeModule.to.bloc<HomeController>();

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: ListView.builder(
        itemCount: controller.list.length,
        itemBuilder: (_, index) {
          TodoModel model = controller.list[index];
          return ItemWidget(model: model);
        },
      ),
    );
  }
}
